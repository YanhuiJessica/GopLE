import csv
import sys
import pandas as pd
import numpy as np
import json

np.set_printoptions(threshold=sys.maxsize)

# First time data load.
ratings = pd.read_csv('./ratings.csv')
users = pd.read_csv('./users.csv')

# users = users.userId.astype('Int32') # note the 'I' is uppercase

# print(users.values[0])
# uuusers=json.dumps(users.values[0])

# Organise a bit and store into feather-format


def nans(df): return df[df.isnull().any(axis=1)]


# Split title and release year in separate columns in movies dataframe. Convert year to timestamp.


iids=users.userId
genders=users.gender
names=users.Username

mIds=ratings.movieId
ratings_=ratings.rating
timestamps=ratings.timestamp
muIds=ratings.userId
j=0
rlen=ratings.shape[0]

LeftA='['
LeftB='{'
RightA=']'
RightB='}'
COMMA=',\n'

MovieId='"movieId":'
Time='"timestamp":'
Gender='"gender":'
Name='"name":'

Tags='"tags":'
TagId='"tagId":'
Tag='"tag":'

Rating='"rating":'
UserId='"userId":'
WatchedMovies='"watchedMovies":'
Escape='"'

with open("out5.json","w") as f:
    # f.write(LeftA)
    for i in range(60550,users.shape[0]):
        f.write(LeftB)
        name=names[i]
        iid=iids[i]
        gender=genders[i]


        f.write(UserId)
        f.write(str(int(iid)))
        f.write(COMMA)
        
        f.write(Name)
        f.write(Escape)
        f.write(str(name))
        f.write(Escape)

        f.write(COMMA)


        f.write(Gender)
        f.write(Escape)

        f.write(gender)
        f.write(Escape)

        f.write(COMMA)
        f.write(WatchedMovies)
        f.write(LeftA)
        f.write("\n")
        while(muIds[j]!=iid and j<rlen ):
            j+=1
        while(j<rlen and muIds[j]==iid):
            f.write(LeftB)
            f.write(MovieId)

            f.write(Escape)
            f.write(str(mIds[j]))
            f.write(Escape)

            f.write(COMMA)

            f.write(Time)
            f.write(str(timestamps[j]))
            f.write(COMMA)
        
            f.write(Rating)

            f.write(str(ratings_[j]))
            f.write(RightB)
       
            f.write(COMMA)
            j+=1
        f.write(RightA)
        f.write(RightB)

        f.write(COMMA)


        f.write("\n")

 
        # continue
        # f.write(RightA)


