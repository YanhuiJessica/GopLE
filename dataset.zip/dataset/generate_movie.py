import csv
import sys
import pandas as pd
import numpy as np
import json

np.set_printoptions(threshold=sys.maxsize)

# First time data load.

movies = pd.read_csv('./movies(1).csv') # movieId,title,genres
scores = pd.read_csv('./toptags.csv') # movieId,tagId,relevance,tag
links = pd.read_csv('./links.csv')# imdbId,tmdbId
info = pd.read_csv('./info.csv') # movieId,votes,rating
links = links.astype('Int32') # note the 'I' is uppercase
favgr = pd.read_csv('./favg.csv') # movieId,avgr
mavgr = pd.read_csv('./mavg.csv') # movieId,avgr

# Organise a bit and store into feather-format
# sort by movieId
movies.sort_values(by='movieId', inplace=True)
movies.reset_index(inplace=True, drop=True)

def nans(df): return df[df.isnull().any(axis=1)]

# Split title and release year in separate columns in movies dataframe. Convert year to timestamp.
movies['year'] = movies.title.str.extract("\((\d{4})\)", expand=True)
null=nans(movies)
movies.dropna(inplace=True)
movies.title = movies.title.str[:-7]
movies['genre'] = movies.genres.str.split('|').tolist()
null['genre'] = null.genres.str.split('|').tolist()

frames = [movies, null]

movies= pd.concat(frames)
movies.sort_values(by='movieId')

title=movies.title
_id=movies.movieId
genres=movies.genre
year=movies.year
j=0

tmId=scores.movieId
tagId=scores.tagId
relevance=scores.relevance
ttag=scores.tag
slen=scores.shape[0]

imdbId=links.imdbId
tmdbId=links.tmdbId

votes=info.votes
rating=info.rating

favg = favgr.avg
mavg = mavgr.avg

LeftA='['
LeftB='{'
RightA=']'
RightB='}'
COMMA=',\n'

MovieId='"movieId":'
Title='"title":'
Year='"year":'
Genres='"genres":'
Tags='"tags":'
TagId='"tagId":'
Tag='"tag":'
Relevance='"relevance":'
Imdb='"imdbId":'
Tmdb='"tmdbId":'
Rating='"rating":'
Votes='"votes":'
Favg='"favg":'
Mavg='"mavg":'
Escape='"'

with open("out2.json","w") as f:
    f.write(LeftA)
    for i in range(0,movies.shape[0]):
        if i % 1000 == 0:
            print("%d success" % i)
        f.write(LeftB)
        t=title[i]
        iid=_id[i]
        gen=json.dumps(genres[i])
        y=year[i]
        
        f.write(MovieId)
        f.write(str(iid))
        f.write(COMMA)
        
        f.write(Title)
        f.write(Escape)
        f.write(t)
        f.write(Escape)

        f.write(COMMA)

        f.write(Year)
        if(type(y) is float):
            f.write(LeftA)
            f.write(RightA)

        else:
            f.write(y)
        f.write(COMMA)

        f.write(Genres)
        f.write(gen)
        f.write(COMMA)

#todo
        f.write(Votes)
        if(votes[i]=='\\N'):
            f.write('0')
        else:
            f.write(votes[i])
        f.write(COMMA)

        f.write(Rating)
        # if(iid==25817):
        #     print(type(rating[i]))
        if(rating[i]=='\\N'):
            f.write('0')
        else:
            f.write(rating[i])
        f.write(COMMA)

 #todo
        f.write(Favg)
        if(favg[i]=='\\N'):
            f.write('0')
        else:
            f.write(favg[i])
        f.write(COMMA)

        f.write(Mavg)
        if(mavg[i]=='\\N'):
            f.write('0')
        else:
            f.write(mavg[i])
        f.write(COMMA)

 #todo       
        f.write(Imdb)
        f.write(str(imdbId[i]))
        f.write(COMMA)
        
        f.write(Tmdb)

        # judge whether is null
        if pd.isna(tmdbId[i]):
            f.write('[]')

        else:
            f.write(str(tmdbId[i]))

        f.write(COMMA)


        f.write(Tags)
        if(j<slen and tmId[j]==iid):
            f.write(LeftA)
            for k in range(0,5):
                f.write(LeftB)
                f.write(Tag)

                f.write(Escape)
                f.write(ttag[j])
                f.write(Escape)

                f.write(COMMA)

                f.write(TagId)
                f.write(str(tagId[j]))
                f.write(COMMA)
            
                f.write(Relevance)

                f.write(str(relevance[j]))
                f.write(RightB)
                if(k!=4):
                    f.write(COMMA)
                j+=1
            f.write(RightA)
            f.write("\n")

            f.write(RightB)
            f.write(COMMA)
        else:
            f.write(LeftA)
            f.write(RightA)
            f.write("\n")

            f.write(RightB)
            f.write(COMMA)
            continue
        # f.write(RightA)